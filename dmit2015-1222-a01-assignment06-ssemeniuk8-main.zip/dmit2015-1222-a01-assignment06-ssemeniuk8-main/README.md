[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-8d59dc4de5201274e310e4c54b9627a8934c3b88527886e3b421487c677d23eb.svg)](https://classroom.github.com/a/IFeD9w8q)
# DMIT2015 Winter 2023 Term assignments

## Sasha Semeniuk

## ssemeniuk8

This is a private repository for your assignments. 
You will use this only for evaluation work. 
Assignment work not submitted within this repository will not be evaluated.
