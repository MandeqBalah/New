package dmit2015.faces;

import dmit2015.restclient.Song;
import dmit2015.restclient.SongMpRestClient;

import jakarta.json.JsonObject;
import lombok.Getter;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.omnifaces.util.Messages;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;

@Named("currentSongCreateView")
@RequestScoped
public class SongCreateView {

    @Inject
    @RestClient
    private SongMpRestClient _songMpRestClient;

    @Getter
    private Song newSong = new Song();

    public String onCreateNew() {
        String nextPage = null;
        try {
            JsonObject responseBody = _songMpRestClient.create(newSong);
            String documentKey = responseBody.getString("name");
            newSong = new Song();
            Messages.addFlashGlobalInfo("Create was successful. {0}", documentKey);
            nextPage = "index?faces-redirect=true";
        } catch (Exception e) {
            e.printStackTrace();
            Messages.addGlobalError("Create was not successful. {0}", e.getMessage());
        }
        return nextPage;
    }

}