package dmit2015.faces;

import dmit2015.restclient.Song;
import dmit2015.restclient.SongMpRestClient;
import lombok.Getter;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.omnifaces.cdi.ViewScoped;
import org.omnifaces.util.Messages;

import jakarta.annotation.PostConstruct;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.io.Serial;
import java.io.Serializable;
import java.util.Map;


@Named("currentSongListView")
@ViewScoped
public class SongListView implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    @Inject
    @RestClient
    private SongMpRestClient _songMpRestClient;

    @Getter
    private Map<String, Song> songMap;

    @PostConstruct  // After @Inject is complete
    public void init() {
        try {
            songMap = _songMpRestClient.findAll();
        } catch (Exception ex) {
            Messages.addGlobalError(ex.getMessage());
        }
    }
}