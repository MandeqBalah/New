package dmit2015.restclient;

import jakarta.enterprise.context.RequestScoped;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.QueryParam;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;
import org.openweathermap.api.CurrentWeatherApiResponse;

@RequestScoped
@RegisterRestClient(baseUri = "http://api.openweathermap.org/geo/1.0")
public interface GeoCodingApiResponseMpRestClient {

    @GET
    @Path("/direct")
    CurrentWeatherApiResponse getCityNames(
            @QueryParam("q") String countryCode, //ISO 3166-2:CA
            @QueryParam("appid") String apiKey,
            @DefaultValue("metric") @QueryParam("units") String units
    );

}