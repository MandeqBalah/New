package dmit2015.restclient;

import jakarta.enterprise.context.RequestScoped;
import jakarta.ws.rs.*;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;
import org.openweathermap.api.CurrentWeatherApiResponse;

@RequestScoped
@RegisterRestClient(baseUri = "https://api.openweathermap.org/data/2.5")
public interface CurrentWeatherApiResponseMpRestClient {

    @GET
    @Path("/weather")
    CurrentWeatherApiResponse getCurrentWeatherByCity(
            @QueryParam("q") String city,
            @QueryParam("appid") String apiKey,
            @DefaultValue("metric") @QueryParam("units") String units
    );

}