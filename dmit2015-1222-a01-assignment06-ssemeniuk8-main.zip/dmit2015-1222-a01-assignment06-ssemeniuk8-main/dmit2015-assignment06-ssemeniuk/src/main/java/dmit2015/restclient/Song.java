package dmit2015.restclient;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class Song {
    private String key;
    @NotBlank(message = "The Song Name field is required.")
    private String songName;
    @NotBlank(message = "The Artist Name field is required.")
    private String artistName;
    private String albumName;
    private Boolean explicit = false;
}
