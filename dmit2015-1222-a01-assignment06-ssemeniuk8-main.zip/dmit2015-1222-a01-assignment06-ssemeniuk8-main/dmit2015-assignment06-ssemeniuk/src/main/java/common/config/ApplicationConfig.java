package common.config;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.faces.annotation.FacesConfig;

@FacesConfig
@ApplicationScoped
public class ApplicationConfig {

}